import os
from src import menu as Menu

try:os.mkdir("CP")
except:pass
try:os.mkdir("OK")
except:pass
Menu.menu()